export default function SwapPage() {
  return (
    <div>
      <h2 className="text-3xl font-bold">Swap vehicles</h2>
      <p className="text-brand.gray mt-2">List your car, set your preferred city, and match securely.</p>
      {/* TODO: swap listings */}
    </div>
  );
}
