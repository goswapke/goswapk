import "./globals.css";
import Link from "next/link";
import { ReactNode } from "react";

export const metadata = {
  title: "GoSwap — Lease or Swap Vehicles",
  description: "Drive your way at your destination.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-brand-gradient text-white">
        <header className="sticky top-0 z-40 backdrop-blur bg-black/10 border-b border-white/10">
          <div className="container flex h-14 items-center justify-between">
            <Link href="/" className="font-bold tracking-wide">GoSwap</Link>
            <nav className="flex items-center gap-6 text-sm">
              <Link href="/lease">Lease</Link>
              <Link href="/swap">Swap</Link>
              <Link href="/how-it-works">How it works</Link>
              <Link href="/contact">Contact</Link>
              <Link href="/auth/signin" className="rounded-full px-4 py-2 bg-brand.aqua text-black font-semibold">Sign in</Link>
            </nav>
          </div>
        </header>
        <main className="container py-10">{children}</main>
        <footer className="mt-16 border-t border-white/10">
          <div className="container py-8 text-sm text-brand.gray flex flex-col md:flex-row items-center justify-between gap-4">
            <div>© {new Date().getFullYear()} GoSwap</div>
            <div className="flex gap-4">
              <a href="#" aria-label="WhatsApp">WhatsApp</a>
              <a href="#" aria-label="Instagram">Instagram</a>
              <a href="#" aria-label="X">X</a>
              <a href="#" aria-label="YouTube">YouTube</a>
            </div>
            <div className="flex gap-4">
              <Link href="/legal/terms">Terms</Link>
              <Link href="/legal/privacy">Privacy</Link>
              <Link href="/legal/refund">Refunds</Link>
            </div>
          </div>
        </footer>
      </body>
    </html>
  );
}
