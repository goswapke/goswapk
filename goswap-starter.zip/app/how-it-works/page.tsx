export default function HowItWorks() {
  return (
    <div className="prose prose-invert max-w-3xl">
      <h2>How GoSwap works</h2>
      <ol>
        <li>Browse vehicles for lease or swap.</li>
        <li>Sign in to book or list.</li>
        <li>For lease: pick dates, arrival time (06:00–22:00), pay, get confirmation.</li>
        <li>For swap: lister & matcher each pay KES 500, contacts revealed when both paid.</li>
      </ol>
    </div>
  );
}
