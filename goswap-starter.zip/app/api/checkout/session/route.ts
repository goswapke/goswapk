import { NextResponse } from "next/server";
import Stripe from "stripe";

export async function POST(req: Request) {
  const { amount, success_url, cancel_url } = await req.json();
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) return NextResponse.json({ error: "Stripe not configured" }, { status: 500 });
  const stripe = new Stripe(key, { apiVersion: "2024-06-20" } as any);
  const session = await stripe.checkout.sessions.create({
    mode: "payment",
    line_items: [{ price_data: { currency: "kes", product_data: { name: "GoSwap Payment" }, unit_amount: amount }, quantity: 1 }],
    success_url: success_url || "http://localhost:3000/checkout/success",
    cancel_url: cancel_url || "http://localhost:3000/checkout/cancel"
  });
  return NextResponse.json({ id: session.id, url: session.url });
}
