import { NextResponse } from "next/server";
import { PrismaClient, Role } from "@prisma/client";
import { hash } from "bcryptjs";

const prisma = new PrismaClient();

export async function POST(req: Request) {
  const { name, email, phone, password, role } = await req.json();
  if (!name || !email || !password) return NextResponse.json({ error: "Missing fields" }, { status: 400 });
  const exists = await prisma.user.findUnique({ where: { email } });
  if (exists) return NextResponse.json({ error: "Email in use" }, { status: 409 });
  const pw = await hash(password, 10);
  const user = await prisma.user.create({
    data: { name, email, phone, password: pw, role: (role === "PARTNER" ? Role.PARTNER : Role.TRAVELER) }
  });
  return NextResponse.json({ ok: true, id: user.id });
}
