export default function LeasePage() {
  return (
    <div>
      <h2 className="text-3xl font-bold">Lease vehicles</h2>
      <p className="text-brand.gray mt-2">Browse self-drive and chauffeured options by city and pickup type.</p>
      {/* TODO: Filters + vehicle grid */}
    </div>
  );
}
