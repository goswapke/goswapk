import Link from "next/link";

export default function Home() {
  return (
    <section className="py-24 text-center">
      <h1 className="mx-auto max-w-3xl text-4xl md:text-6xl font-extrabold leading-tight">
        Drive your way at your destination.
      </h1>
      <p className="mt-4 text-lg text-brand.gray">The right car, right where you land — lease or swap in minutes.</p>
      <div className="mt-8 flex gap-4 justify-center">
        <Link href="/lease" className="rounded-full px-6 py-3 bg-white text-black font-semibold shadow-card hover:shadow-hover transition">Lease a Vehicle</Link>
        <Link href="/swap" className="rounded-full px-6 py-3 border border-white/30 text-white font-semibold hover:bg-white/10 transition">Swap a Vehicle</Link>
      </div>
    </section>
  );
}
