type Props = { params: { id: string } };

export default async function VehicleDetail({ params }: Props) {
  return (
    <div>
      <h2 className="text-3xl font-bold">Vehicle #{params.id}</h2>
      <p className="text-brand.gray mt-2">Photos, description, prices (self-drive & chauffeured), pickup options.</p>
      {/* TODO: fetch vehicle by id */}
    </div>
  );
}
