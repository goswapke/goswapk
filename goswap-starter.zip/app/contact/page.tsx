export default function Contact() {
  return (
    <div className="max-w-xl space-y-2">
      <h2 className="text-3xl font-bold">Contact GoSwap</h2>
      <p className="text-brand.gray">WhatsApp +254 715 740 270 • Email support@goswap.example</p>
    </div>
  );
}
